"use strict";

/*
    Smart Rehabilitation Monitoring System

    Frontend prototype.

    Wearables:
    - Smart T-shirt: IMU + sEMG
    - Smart Knee Socks: IMU

    The current values are simulated for demonstration.
    Later, replace the simulation with real ESP32/backend data.
*/


// ==========================================
// REHABILITATION DATA
// ==========================================

const rehabData = {
    patientId: "Patient 001",
    exercise: "Knee Flexion",

    targetMinAngle: 85,
    targetMaxAngle: 95,

    kneeAngle: 88,
    semg: 62,

    totalReps: 20,
    correctReps: 16,
    incorrectReps: 4
};


// ==========================================
// GET HTML ELEMENTS
// ==========================================

const kneeAngleElement = document.getElementById("kneeAngle");
const semgElement = document.getElementById("semgValue");
const movementQualityElement =
    document.getElementById("movementQuality");

const accuracyElement = document.getElementById("accuracy");
const totalRepsElement = document.getElementById("totalReps");
const correctRepsElement = document.getElementById("correctReps");
const incorrectRepsElement =
    document.getElementById("incorrectReps");

const progressBar = document.getElementById("progressBar");
const riskLevelElement = document.getElementById("riskLevel");

const alertList = document.getElementById("alertList");
const testAlertButton = document.getElementById("testAlert");

const doctorNotification =
    document.getElementById("doctorNotification");

const caretakerNotification =
    document.getElementById("caretakerNotification");


// ==========================================
// CALCULATE ACCURACY
// ==========================================

function calculateAccuracy() {
    if (rehabData.totalReps === 0) {
        return 0;
    }

    return Math.round(
        (rehabData.correctReps / rehabData.totalReps) * 100
    );
}


// ==========================================
// DETERMINE MOVEMENT QUALITY
// ==========================================

function getMovementQuality(angle) {

    if (
        angle >= rehabData.targetMinAngle &&
        angle <= rehabData.targetMaxAngle
    ) {
        return "GOOD";
    }

    const difference = Math.min(
        Math.abs(angle - rehabData.targetMinAngle),
        Math.abs(angle - rehabData.targetMaxAngle)
    );

    if (difference <= 10) {
        return "WARNING";
    }

    return "INCORRECT";
}


// ==========================================
// DETERMINE RISK LEVEL
// ==========================================

function calculateRisk() {

    const accuracy = calculateAccuracy();

    if (accuracy >= 80) {
        return "LOW";
    }

    if (accuracy >= 60) {
        return "MEDIUM";
    }

    return "HIGH";
}


// ==========================================
// UPDATE RISK DISPLAY
// ==========================================

function updateRiskDisplay() {

    const risk = calculateRisk();

    if (!riskLevelElement) {
        return;
    }

    riskLevelElement.textContent = risk;

    if (risk === "LOW") {
        riskLevelElement.style.color = "#1f9d55";
    }
    else if (risk === "MEDIUM") {
        riskLevelElement.style.color = "#e69500";
    }
    else {
        riskLevelElement.style.color = "#d93025";
    }
}


// ==========================================
// UPDATE MOVEMENT QUALITY
// ==========================================

function updateMovementQuality() {

    if (!movementQualityElement) {
        return;
    }

    const quality =
        getMovementQuality(rehabData.kneeAngle);

    movementQualityElement.textContent = quality;

    movementQualityElement.className = "quality";

    if (quality === "GOOD") {
        movementQualityElement.classList.add("good");
    }
    else if (quality === "WARNING") {
        movementQualityElement.classList.add("warning");
    }
    else {
        movementQualityElement.classList.add("bad");
    }
}


// ==========================================
// UPDATE DASHBOARD
// ==========================================

function updateDashboard() {

    if (kneeAngleElement) {
        kneeAngleElement.textContent = rehabData.kneeAngle;
    }

    if (semgElement) {
        semgElement.textContent = rehabData.semg;
    }

    if (totalRepsElement) {
        totalRepsElement.textContent = rehabData.totalReps;
    }

    if (correctRepsElement) {
        correctRepsElement.textContent = rehabData.correctReps;
    }

    if (incorrectRepsElement) {
        incorrectRepsElement.textContent = rehabData.incorrectReps;
    }

    const accuracy = calculateAccuracy();

    if (accuracyElement) {
        accuracyElement.textContent = accuracy + "%";
    }

    if (progressBar) {
        progressBar.style.width = accuracy + "%";
    }

    updateMovementQuality();
    updateRiskDisplay();
}


// ==========================================
// CREATE ALERT
// ==========================================

function createAlert(message, angle, severity = "HIGH") {

    if (!alertList) {
        return;
    }

    const noAlert =
        alertList.querySelector(".no-alert");

    if (noAlert) {
        noAlert.remove();
    }

    const alertItem =
        document.createElement("div");

    alertItem.className = "alert-item";

    const currentTime =
        new Date().toLocaleTimeString();

    alertItem.innerHTML = `
        <strong>${severity} MOVEMENT ALERT</strong>

        <span>${message}</span>

        <br>

        <span>Knee angle: ${angle}°</span>

        <br>

        <span>Time: ${currentTime}</span>
    `;

    alertList.prepend(alertItem);

    sendNotification(message, angle);
}


// ==========================================
// SEND NOTIFICATION
// ==========================================

function sendNotification(message, angle) {

    const recipients = [];

    if (
        doctorNotification &&
        doctorNotification.checked
    ) {
        recipients.push("Doctor / Physiotherapist");
    }

    if (
        caretakerNotification &&
        caretakerNotification.checked
    ) {
        recipients.push("Caretaker");
    }

    if (recipients.length === 0) {
        console.log("No notification recipients selected.");
        return;
    }

    /*
        Prototype notification.

        In the real system, this should call
        your secure backend.

        Example:

        fetch("/api/alerts", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                patientId: rehabData.patientId,
                message: message,
                kneeAngle: angle,
                recipients: recipients
            })
        });

        Do NOT put private API keys or service-role
        keys inside this JavaScript file.
    */

    console.log("Notification sent to:", recipients);
}


// ==========================================
// SIMULATE INCORRECT MOVEMENT
// ==========================================

function simulateIncorrectMovement() {

    rehabData.kneeAngle = 55;
    rehabData.semg = 38;

    rehabData.incorrectReps++;
    rehabData.totalReps++;

    updateDashboard();

    createAlert(
        "Patient performed an incorrect knee movement.",
        rehabData.kneeAngle,
        "HIGH"
    );
}


// ==========================================
// SIMULATE CORRECT MOVEMENT
// ==========================================

function simulateCorrectMovement() {

    rehabData.kneeAngle = 90;
    rehabData.semg = 65;

    rehabData.correctReps++;
    rehabData.totalReps++;

    updateDashboard();
}


// ==========================================
// TEST ALERT BUTTON
// ==========================================

if (testAlertButton) {

    testAlertButton.addEventListener(
        "click",
        function () {
            simulateIncorrectMovement();
        }
    );

}


// ==========================================
// SIMULATE LIVE SENSOR DATA
// ==========================================

function simulateLiveSensorData() {

    /*
        This generates demonstration values.

        Later, replace this with actual ESP32
        IMU and sEMG data received through
        Bluetooth/Wi-Fi/backend.
    */

    const randomMovement = Math.random();

    if (randomMovement < 0.8) {

        rehabData.kneeAngle =
            Math.floor(85 + Math.random() * 11);

        rehabData.semg =
            Math.floor(55 + Math.random() * 20);

    }
    else {

        rehabData.kneeAngle =
            Math.floor(50 + Math.random() * 25);

        rehabData.semg =
            Math.floor(30 + Math.random() * 15);
    }

    updateDashboard();
}


// ==========================================
// START APPLICATION
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        updateDashboard();

        console.log(
            "Smart Rehabilitation Monitor started."
        );
    }
);
